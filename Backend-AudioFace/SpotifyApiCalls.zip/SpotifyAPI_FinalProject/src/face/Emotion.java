package face;

import java.util.HashMap;
import java.util.Map;

public class Emotion {

private Double contempt;
private Double surprise;
private Double happiness;
private Double neutral;
private Double sadness;
private Double disgust;
private Double anger;
private Double fear;
private Map<String, Object> additionalProperties = new HashMap<String, Object>();

public Double getContempt() {
return contempt;
}

public void setContempt(Double contempt) {
this.contempt = contempt;
}

public Double getSurprise() {
return surprise;
}

public void setSurprise(Double surprise) {
this.surprise = surprise;
}

public Double getHappiness() {
return happiness;
}

public void setHappiness(Double happiness) {
this.happiness = happiness;
}

public Double getNeutral() {
return neutral;
}

public void setNeutral(Double neutral) {
this.neutral = neutral;
}

public Double getSadness() {
return sadness;
}

public void setSadness(Double sadness) {
this.sadness = sadness;
}

public Double getDisgust() {
return disgust;
}

public void setDisgust(Double disgust) {
this.disgust = disgust;
}

public Double getAnger() {
return anger;
}

public void setAnger(Double anger) {
this.anger = anger;
}

public Double getFear() {
return fear;
}

public void setFear(Double fear) {
this.fear = fear;
}

public Map<String, Object> getAdditionalProperties() {
return this.additionalProperties;
}

public void setAdditionalProperty(String name, Object value) {
this.additionalProperties.put(name, value);
}

}